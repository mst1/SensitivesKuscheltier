#!/bin/bash
#EXECUTE THIS AS ROOT
mkdir /usr/projectpi
tar -xf content.tar /usr/projectpi/
cp projectpi /usr/bin/
chmod +x /usr/bin/projectpi
