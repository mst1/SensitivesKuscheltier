#Imports
import RPi.GPIO as GPIO
import socket
import os
import thread
import pyglet
import picamera
import time

os.chdir('/usr/projectpi')

#Programmstart
print 'Software Raspberry Pi starting'
#Portkonstante
PORT = 50000;

#GPIO Sensor Numbers
LH_SELFIE = 29
RH_TASTER = 31
OHR_TASTER = 23
APRX = 35
BELLY = 33
#GPIO RGB Led
LEFT_RGB_R=7
LEFT_RGB_G=11
LEFT_RGB_B=13
RIGHT_RGB_R=15
RIGHT_RGB_G=19
RIGHT_RGB_B=21

#GPIO_setup_Sensoren
GPIO.setup(LH_SELFIE, GPIO.IN)
GPIO.setup(RH_TASTER, GPIO.IN)
GPIO.setup(OHR_TASTER, GPIO.IN)
GPIO.setup(APRX, GPIO.IN)
GPIO.setup(BELLY, GPIO.IN)
#GPIO_setup_LEDs
GPIO.setup(LEFT_RGB_B, GPIO.OUT, GPIO.LOW)
GPIO.setup(LEFT_RGB_G, GPIO.OUT, GPIO.LOW)
GPIO.setup(LEFT_RGB_R, GPIO.OUT, GPIO.LOW)
GPIO.setup(RIGHT_RGB_B, GPIO.OUT, GPIO.LOW)
GPIO.setup(RIGHT_RGB_G, GPIO.OUT, GPIO.LOW)
GPIO.setup(RIGHT_RGB_R, GPIO.OUT, GPIO.LOW)

#Start des Servers
def init_netw():
	s = socket.socket()
	s.bind(('', PORT))
	s.listen(1)
	while True:
		c, a=s.accept()
		cmd = c.recv(1024)
        netcmd(cmd)

def playsound(sound):
	music = pyglet.resource.media(sound)
	music.play()
	pyglet.app.run()

def augenfarbe(r, g, b):
	thread.start_new_thread(augenfarbe_thread(r, g, b))

def augenfarbe_thread(r, g, b):
	if(r==True):
		GPIO.output(LEFT_RGB_R, 1)
		GPIO.output(RIGHT_RGB_R, 1)
	else:
		GPIO.output(LEFT_RGB_R, 0)
		GPIO.output(RIGHT_RGB_R, 0)
	if(g==True):
		GPIO.output(LEFT_RGB_G, 1)
		GPIO.output(RIGHT_RGB_G, 1)
	else:
		GPIO.output(LEFT_RGB_G, 0)
		GPIO.output(RIGHT_RGB_G, 0)
	if(b==True):
		GPIO.output(LEFT_RGB_B, 1)
		GPIO.output(RIGHT_RGB_B, 1)
	else:
		GPIO.output(LEFT_RGB_B, 0)
		GPIO.output(RIGHT_RGB_B, 0)
	time.sleep(3)
	GPIO.output(LEFT_RGB_R, 0)
	GPIO.output(RIGHT_RGB_R, 0)
	GPIO.output(LEFT_RGB_G, 0)
	GPIO.output(RIGHT_RGB_G, 0)
	GPIO.output(LEFT_RGB_B, 0)
	GPIO.output(RIGHT_RGB_B, 0)

def pic():
	tmp = time.strftime("%d_%m_%Y_%H_%M_%S")
	PICAM.capture('/Fotos/'+tmp+'.jpg')
	
def netcmd(cmd):
	if (cmd=='shutd'):
		os.system("shutdown now -h")
	elif (cmd=='killsoft'):
		RUNNING = False
	elif (cmd=='reboot'):
		os.system("reboot")
	elif (cmd=='ledred'):
		print 'Red eyes'
		augenfarbe(True, False, False)
	elif (cmd=='ledgreen'):
		print 'Green eyes'
		augenfarbe(False, True, False)
	elif (cmd=='ledblue'):
		print 'Blue eyes'
		augenfarbe(False, False, True)
	elif (cmd=='ledyellow'):
		print 'Yellow eyes'
		augenfarbe(True, True, False)
	elif (cmd=='ledmagenta'):
		print 'Magenta eyes'
		augenfarbe(True, False, True)
	elif (cmd=='ledtuerkis'):
		print 'Turkies eyes'
		augenfarbe(False, True, True)
	elif (cmd=='ledwhite'):
		print 'White eyes'
		augenfarbe(True, True, True)
	elif (cmd=='ledblank'):
		print 'Blank eyes'
		augenfarbe(False, False, False)

#Taster + Annaeherung
def action(gpio):
	if gpio==LH_SELFIE:
		print 'Left hand'
		playsound('Foto.wav')
		augenfarbe(True, True, True)
		pic()
	elif gpio==RH_TASTER:
		print 'Right Hand'
		augenfarbe(True, True, False)
		playsound('Donnerblitz.wav')
	elif gpio==OHR_TASTER:
		print 'Ear'
		playsound('Ear.wav')
	elif gpio==APRX:
		print 'Object near'
		augenfarbe(False, True, True)
		playsound('Annaeherung.wav')
	elif gpio==BELLY:
		print 'Belly'
		augenfarbe(True, False, False)
		playsound('Bauch.wav')

#GPIOs start
GPIO.setmode(GPIO.BOARD)
GPIO.add_event_callback(LH_SELFIE, action(LH_SELFIE), GPIO.RISING);
GPIO.add_event_callback(RH_TASTER, action(RH_TASTER), GPIO.RISING);
GPIO.add_event_callback(OHR_TASTER, action(OHR_TASTER), GPIO.RISING);
GPIO.add_event_callback(APRX, action(APRX), GPIO.RISING);

thread.start_new_thread(init_netw())

def softclose():
	#GPIOs freigeben
	GPIO.cleanup()
	#Programm beenden
	playsound('Ausschalten.wav')
	exit()

#Programm nicht anhalten
RUNNING = True
while True:
	continue